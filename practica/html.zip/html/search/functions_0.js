var searchData=
[
  ['afegir_5fespecie_57',['afegir_especie',['../class_cjt__especies.html#a5897b9efb4c1b824a93a0e650d9623b8',1,'Cjt_especies']]]
];
