var searchData=
[
  ['idn_24',['idn',['../class_especie.html#a8741158ce98be7fccf29586ef18b4349',1,'Especie']]],
  ['imprimir_5farbre_5ffilogenetic_25',['imprimir_arbre_filogenetic',['../class_cjt__clusters.html#adb8d225a15b47afca25d842d10088a21',1,'Cjt_clusters']]],
  ['imprimir_5ftaula_5fdistancies_26',['imprimir_taula_distancies',['../class_cjt__clusters.html#a2ee45d5dabc656adf8d7d356239f57c6',1,'Cjt_clusters::imprimir_taula_distancies()'],['../class_cjt__especies.html#aeb2402fbb6b5cc5eeea31981c51110bc',1,'Cjt_especies::imprimir_taula_distancies()']]],
  ['it_5fclust_27',['it_clust',['../class_cjt__especies.html#af480e4837cf157ff185cef3db7ce7cbb',1,'Cjt_especies']]]
];
