var searchData=
[
  ['distancia_14',['distancia',['../class_especie.html#aa65b597d739650b43db8dfe85c37a8bc',1,'Especie']]],
  ['distancies_15',['distancies',['../class_cjt__clusters.html#a23124c3691e626f5d66ec1d59859b120',1,'Cjt_clusters::distancies()'],['../class_cjt__especies.html#a89696ade836937b116d625741a15fb27',1,'Cjt_especies::distancies()']]]
];
