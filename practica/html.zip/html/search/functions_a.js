var searchData=
[
  ['recalcular_5fmin_80',['recalcular_min',['../class_cjt__clusters.html#af987c08c1790adeae8f683a810957b83',1,'Cjt_clusters']]]
];
