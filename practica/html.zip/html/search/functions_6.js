var searchData=
[
  ['imprimir_5farbre_5ffilogenetic_72',['imprimir_arbre_filogenetic',['../class_cjt__clusters.html#adb8d225a15b47afca25d842d10088a21',1,'Cjt_clusters']]],
  ['imprimir_5ftaula_5fdistancies_73',['imprimir_taula_distancies',['../class_cjt__clusters.html#a2ee45d5dabc656adf8d7d356239f57c6',1,'Cjt_clusters::imprimir_taula_distancies()'],['../class_cjt__especies.html#aeb2402fbb6b5cc5eeea31981c51110bc',1,'Cjt_especies::imprimir_taula_distancies()']]]
];
