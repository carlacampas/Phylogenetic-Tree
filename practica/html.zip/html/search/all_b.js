var searchData=
[
  ['pràctica_20pro2_20primavera_2020_2f05_2f2020_3a_20carla_20campàs_20gené_34',['Pràctica PRO2 Primavera 20/05/2020: Carla Campàs Gené',['../index.html',1,'']]],
  ['pas_5fwpgma_35',['pas_wpgma',['../class_cjt__clusters.html#a0675e6339f6a8fad8219518c377fbcf9',1,'Cjt_clusters']]],
  ['principi_36',['principi',['../class_cjt__especies.html#aea7a57445bfb14dad5f52fe944986302',1,'Cjt_especies']]],
  ['produir_5fkmer_37',['produir_kmer',['../class_especie.html#a82e78eda6307a53b3eab2c50e96963f4',1,'Especie']]],
  ['program_2ecc_38',['program.cc',['../program_8cc.html',1,'']]],
  ['proper_39',['proper',['../class_cjt__especies.html#aef81fccef00fa6209d94dcdd0bc52593',1,'Cjt_especies']]]
];
