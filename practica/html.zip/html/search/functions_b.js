var searchData=
[
  ['search_81',['search',['../class_cjt__especies.html#ac9fee1e27765d1ea23b190d92eddd523',1,'Cjt_especies']]],
  ['set_5fk_82',['set_k',['../class_especie.html#af3054dc7de33129530e4322fc0cdd89c',1,'Especie']]]
];
