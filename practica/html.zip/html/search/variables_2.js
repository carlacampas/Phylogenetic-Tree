var searchData=
[
  ['idn_89',['idn',['../class_especie.html#a8741158ce98be7fccf29586ef18b4349',1,'Especie']]],
  ['it_5fclust_90',['it_clust',['../class_cjt__especies.html#af480e4837cf157ff185cef3db7ce7cbb',1,'Cjt_especies']]]
];
