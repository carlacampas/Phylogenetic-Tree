var searchData=
[
  ['elimina_5fespecie_67',['elimina_especie',['../class_cjt__especies.html#adefff1c82b604e97f25efbf8e0c39e30',1,'Cjt_especies']]],
  ['escriure_68',['escriure',['../class_cjt__especies.html#a07950c5f2b1c3e0384f246381ed7bd97',1,'Cjt_especies::escriure()'],['../class_especie.html#ae24802ae0746b2560a48eea40f64760e',1,'Especie::escriure()']]],
  ['escriure_5fcluster_69',['escriure_cluster',['../class_cjt__clusters.html#adc450d577a93cb20435dd86d5fb8e7cf',1,'Cjt_clusters']]],
  ['especie_70',['Especie',['../class_especie.html#a272c2488719cc9874b2f174906675b3d',1,'Especie']]]
];
