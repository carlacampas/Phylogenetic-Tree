var searchData=
[
  ['llegir_74',['llegir',['../class_cjt__especies.html#a256b1c2e155f674e1de486952fb7507a',1,'Cjt_especies::llegir()'],['../class_especie.html#a7384add391d2684c4fb6bdf8a535fba3',1,'Especie::llegir()']]]
];
