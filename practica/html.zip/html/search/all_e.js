var searchData=
[
  ['tamany_43',['tamany',['../class_cjt__clusters.html#a9bd0a69e73ed3e5f27e5bf2050d62896',1,'Cjt_clusters']]]
];
